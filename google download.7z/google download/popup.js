document.getElementById("downloadBtn").addEventListener("click", () => {
  const text = document.getElementById("links").value.trim();
  if (!text) return;

  const links = text.split("\n");

  links.forEach((link, index) => {
    const fileId = extractDriveFileId(link);
    if (!fileId) return;

    const downloadUrl = `https://drive.google.com/uc?export=download&id=${fileId}`;

    chrome.downloads.download({
          url: downloadUrl,
          filename: `google_image_${index + 1}.jpg`,
           saveAs: index === 0 
});

  });
});

// 提取 Google Drive 文件 ID
function extractDriveFileId(url) {
  const match = url.match(/\/d\/([a-zA-Z0-9_-]+)/);
  return match ? match[1] : null;
}
